<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<hr>
<footer class="footer">
	<div class="container">
		<p class="text-muted">Movies Collection - Syauqi Damario Djohan - 2019 </p>
	</div>
</footer>

<style>
	.footer {
	left: 0;
	bottom: 0;
	width: 100%;
	background-color: white;
	color: grey;
	text-align: center;
}

hr {
	border : 0.3px solid black;
}
</style>