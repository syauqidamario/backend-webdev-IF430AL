<!DOCTYPE html>
<html lang='en'>
<head>
	<title>Week 13</title>
	<?php echo $style; ?>
</head>

<body>
	<?php echo $navbar; ?>
	<div class="row" style="margin-top: 100px;">
		<div class="col-md-12"><?php echo $crud['output'];?></div>
	</div>
	<?php echo $footer; ?>
	<?php echo $script; ?>
</body>
</html>