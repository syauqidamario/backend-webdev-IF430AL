<!DOCTYPE html>
<html>
<head>
	<title> Tugas Pendahuluan</title>
	<!-- Bootstrap -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Data Tables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
	<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#products').DataTable();
		} );
	</script>
</head>
<body>
	<header>
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class= "navbar-header" >
                    <a class="navbar-brand" href="#"> [IF635] Web Programming  </a>
                </div>
                <div>
                    <ul class="nav navbar-nav navbar-right">
                        <li class= "active" ><a href="#"> Employees </a></li>
                    </ul>
                </div>
            </div>
        </nav>
	</header>
	<div class="container">
		<table id="products" class="table table-stripped table-bordered" style="width:100%">
			<thead>
				<tr>
					<th> supplier_ids</th>
					<th> id </th>
					<th> product_code </th>
					<th> product_name </th>
					<th> description </th>
					<th> standard_cost </th>
					<th> list_price </th>
					<th> reorder_level </th>
					<th> target_level </th>
					<th> quantity_per_unit</th>
					<th> discontinued </th>
					<th> minimum_reorder_quantity</th>
					<th> category </th>
					<th> attachments </th>
				</tr>
			</thead>
			<tbody>
				<?php
					$host = "localhost";
					$username = "root";
					$dbname = "northwind";
					$password = "iloveyou3000";

					$db = new mysqli($host, $username, $password, $dbname);

					$query = "SELECT * FROM products LIMIT 12";
					$result = $db->query($query);

					while($row = $result -> fetch_assoc()){
						echo "<tr>";
						echo "<td>" . $row['supplier_ids'] . "</td>";
						echo "<td>" . $row['id'] . "</td>";
						echo "<td>" . $row['product_code'] . "</td>";
						echo "<td>" . $row['product_name'] . "</td>";
						echo "<td>" . $row['description'] . "</td>";
						echo "<td>" . $row['standard_cost'] . "</td>";
						echo "<td>" . $row['list_price'] . "</td>";
						echo "<td>" . $row['reorder_level'] . "</td>";
						echo "<td>" . $row['target_level'] . "</td>";
						echo "<td>" . $row['quantity_per_unit'] . "</td>";
						echo "<td>" . $row['discontinued'] . "</td>";
						echo "<td>" . $row['minimum_reorder_quantity'] . "</td>";
						echo "<td>" . $row['category'] . "</td>";
						echo "<td>" . $row['attachments']. "</td>";
						echo"</tr>";
					}
					mysqli_free_result($result);
					mysqli_close($db);
				?>
			</tbody>
		</table>
	</div>
</body>
</html>