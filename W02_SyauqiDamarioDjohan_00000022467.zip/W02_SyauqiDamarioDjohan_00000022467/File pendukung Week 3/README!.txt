File yang dikumpulkan ada 3 macam :

1. cunderstanding_answer.txt;
2. employee_mysqli.php;
3. employee_pdo.php;
4. challenge.php;