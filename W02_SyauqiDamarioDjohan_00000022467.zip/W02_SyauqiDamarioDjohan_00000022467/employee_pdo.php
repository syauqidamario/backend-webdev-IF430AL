<!DOCTYPE html>
<html>
<head>
	<title> Tugas Pendahuluan</title>
	<!-- Bootstrap -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Data Tables -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css">
	<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#products').DataTable();
		} );
	</script>
</head>
<body>
	<header>
		<nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class= "navbar-header" >
                    <a class="navbar-brand" href="#"> [IF635] Web Programming  </a>
                </div>
                <div>
                    <ul class="nav navbar-nav navbar-right">
                        <li class= "active" ><a href="#"> Employees </a></li>
                    </ul>
                </div>
            </div>
        </nav>
	</header>
	<div class="container">
		<table id="products" class="table table-stripped table-bordered" style="width:100%">
			<thead>
				<tr>
					<th> supplier_ids </th>
					<th> id </th>
					<th> product_code </th>
					<th> product_name </th>
					<th> description </th>
					<th> standard_cost </th>
					<th> list_price </th>
					<th> reorder_level</th>
					<th> target_level</th>
					<th> quantity_per_unit</th>
					<th> discontinued </th>
					<th> minimum_reorder_quantity</th>
					<th> category</th>
					<th> attachments </th>
				</tr>
			</thead>
			<tbody>
				<?php
					$host = "localhost";
					$username = "root";
					$dbname = "northwind";
					$password = "iloveyou3000";

					$conn = new PDO("mysql:host=$host;dbname=$dbname;",$username, $password);

					$query = "SELECT * FROM products LIMIT 12";
					$result = $conn->query($query);

					foreach($result as $row){
						echo "<tr>";
						echo "<td>" . $row[0] . "</td>";
						echo "<td>" . $row[1] . "</td>";
						echo "<td>" . $row[2] . "</td>";
						echo "<td>" . $row[3] . "</td>";
						echo "<td>" . $row[4] . "</td>";
						echo "<td>" . $row[5] . "</td>";
						echo "<td>" . $row[6] . "</td>";
						echo "<td>" . $row[7] . "</td>";
						echo "<td>" . $row[8] . "</td>";
						echo "<td>" . $row[9] . "</td>";
						echo "<td>" . $row[10] . "</td>";
						echo "<td>" . $row[11] . "</td>";
						echo "<td>" . $row[12] . "</td>";
						echo "<td>" . $row[13] . "</td>";
						echo"</tr>";
					}
					$result = null;
					$conn = null;
				?>
			</tbody>
			<tfoot>
				<tr>
					<td> # </td>
					<td> Product Name </td>
					<td> Quantity Per Unit </td>
					<td> Price </td>
					<td> Stock </td>
				</tr>
			</tfoot>
		</table>
	</div>
</body>
</html>