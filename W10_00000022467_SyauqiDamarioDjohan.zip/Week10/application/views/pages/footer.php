<div class="text-center footer">
	<p>Copyright 2019 - Syauqi Damario Djohan - 00000022467</p>
</div>

<style>
.footer{
	position: fixed;
	left: 0;
	bottom: 0;
	width: 100%;
	background-color: grey;
	color: #EEEEEE;
	text-align: center;
}
</style>