<?php
    $negara = array(
        "India" => array(
            "ibuKota" => "New Delhi",
            "kodeTel" => "91",
            "mataUang" => "INR"
        ),
        "Indonesia" => array(
            "ibuKota" => "Jakarta",
            "kodeTel" => "62",
            "mataUang" => "IDR"
        ),
        "Japan" => array(
            "ibuKota" => "Tokyo",
            "kodeTel" => "81",
            "mataUang" => "JPY"
        )
    );

    foreach($negara as $nama => $data){
        echo "<b><i>$data[ibuKota]</i></b> is capital city of <b>$nama</b>. <u>$nama's calling code is $data[kodeTel] and has \"$data[mataUang]\" as currency code.</u><br>";
    }
?>